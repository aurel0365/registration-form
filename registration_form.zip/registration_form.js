document.getElementById('registrationForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const formData = new FormData(this);
    const displayDiv = document.getElementById('displayData');
    displayDiv.innerHTML = ''; // Clear previous data
    
    for (let [key, value] of formData.entries()) {
        if (key !== 'photo') { // Skip displaying 'photo' key
            const paragraph = document.createElement('p');
            paragraph.textContent = `${key}: ${value}`;
            displayDiv.appendChild(paragraph);
        }
    }
    
    // Display uploaded image
    const photoInput = document.getElementById('photo');
    const photoPreview = document.getElementById('photoPreview');
    const file = photoInput.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(event) {
            photoPreview.src = event.target.result;
            photoPreview.style.display = 'block';
            displayDiv.appendChild(photoPreview); // Move image to displayDiv
        };
        reader.readAsDataURL(file);
    }
    
    // Show output container
    const outputContainer = document.getElementById('outputContainer');
    outputContainer.style.display = 'block';
});

